# TijariQA

A Pen created on CodePen.

Original URL: [https://codepen.io/hasoon-sawari/pen/WbQajjr](https://codepen.io/hasoon-sawari/pen/WbQajjr).

